
package com.penandpaper.app.ui.editor
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.compose.foundation.layout.Box
import com.penandpaper.app.ui.theme.FolderTheme

data class BlockStyle(
    val fontFamily: String = "Sans",
    val fontSize: Int = 16,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false
)

@Composable
fun EditorScreen(noteId: Long, onBack: () -> Unit, vm: EditorViewModel = hiltViewModel()) {
    LaunchedEffect(noteId) { vm.load(noteId) }
    val title by vm.title.collectAsState()
    val blocks by vm.blocks.collectAsState()
    val saver = remember { AutoSaver(vm.viewModelScope) }
    Scaffold(
        topBar = { TopAppBar(colors = FolderTheme.appBarColors(), title = { Text(title.ifEmpty { "Untitled" }) }) },
        floatingActionButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ExtendedFloatingActionButton(text = { Text("Text") }, onClick = vm::addTextBlock)
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            PageBackground("ruled")
            Column(Modifier.padding(16.dp)) {
            var t by remember(title) { mutableStateOf(title) }
            OutlinedTextField(t, onValueChange = {
                t = it; vm.setTitle(it); saver.schedule { vm.persistDraft() }
            }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(blocks.size) { i ->
                    val styleState = remember { mutableStateOf(vm.getBlockStyle(i)) }
                    val st = styleState.value
                    OutlinedCard(Modifier.fillMaxWidth()) {
                        EditorToolbar(
                            fontFamily = st.fontFamily,
                            onFontFamily = { ff -> styleState.value = st.copy(fontFamily = ff); vm.setBlockStyle(i, styleState.value); saver.schedule { vm.persistDraft() } },
                            fontSize = st.fontSize,
                            onFontSize = { fs -> styleState.value = st.copy(fontSize = fs); vm.setBlockStyle(i, styleState.value); saver.schedule { vm.persistDraft() } },
                            bold = st.bold, onBold = { b -> styleState.value = st.copy(bold = b); vm.setBlockStyle(i, styleState.value); saver.schedule { vm.persistDraft() } },
                            italic = st.italic, onItalic = { itl -> styleState.value = st.copy(italic = itl); vm.setBlockStyle(i, styleState.value); saver.schedule { vm.persistDraft() } },
                            underline = st.underline, onUnderline = { u -> styleState.value = st.copy(underline = u); vm.setBlockStyle(i, styleState.value); saver.schedule { vm.persistDraft() } }
                        )
                        var content by remember { mutableStateOf(vm.getTextContent(i)) }
                        val ff = when (st.fontFamily) {
                            "Serif" -> FontFamily.Serif
                            "Mono" -> FontFamily.Monospace
                            else -> FontFamily.SansSerif
                        }
                        val deco = if (st.underline) TextDecoration.Underline else TextDecoration.None
                        val weight = if (st.bold) FontWeight.Bold else FontWeight.Normal
                        val fontStyle = if (st.italic) FontStyle.Italic else FontStyle.Normal
                        BasicTextField(
                            value = content,
                            onValueChange = { content = it; vm.setTextContent(i, it); saver.schedule { vm.persistDraft() } },
                            textStyle = TextStyle(fontFamily = ff, fontSize = st.fontSize.sp, fontWeight = weight, fontStyle = fontStyle, textDecoration = deco),
                            modifier = Modifier.padding(16.dp).fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}
