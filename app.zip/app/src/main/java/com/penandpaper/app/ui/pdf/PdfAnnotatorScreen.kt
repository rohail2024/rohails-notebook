
package com.penandpaper.app.ui.pdf
import android.graphics.PointF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import com.penandpaper.app.ui.theme.FolderTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

@Composable
fun PdfAnnotatorScreen() {
    val highlightColor = if (com.penandpaper.app.ui.theme.FolderTheme.useAccentForHighlights)
        com.penandpaper.app.ui.theme.FolderTheme.accentColor(Color.Yellow)
    else Color.Yellow
    Scaffold(topBar = { TopAppBar(colors = FolderTheme.appBarColors(), title = { Text("PDF Annotator") }) }) { pad ->
        Column(Modifier.padding(pad)) {
    var tool by remember { mutableStateOf("Ink")         }
    }
}
    val points = remember { mutableStateListOf<PointF>()         }
    }
}
            // tools + canvas
            Column {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = tool=="Ink", onClick = { tool="Ink" }, label = { Text("Ink") })
            FilterChip(selected = tool=="Highlight", onClick = { tool="Highlight" }, label = { Text("Highlight") })
            FilterChip(selected = tool=="Text", onClick = { tool="Text" }, label = { Text("Text") })
                }
    }
}
        Canvas(Modifier.fillMaxSize().background(Color.White).pointerInput(Unit) {
            detectDragGestures(onDrag = { change, _ ->
                val p = change.position
                points.add(PointF(p.x, p.y))
            })
        }) {
            // Placeholder for annotator UI layer
                }
    }
}
            }
    }
}
        }
    }
}
